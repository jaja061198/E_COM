If you're coming from the youtube video, here are the relevant files:

* [welcome.blade.php](https://github.com/drehimself/css-grid-example/blob/master/resources/views/welcome.blade.php)
* [app.scss](https://github.com/drehimself/css-grid-example/blob/master/resources/assets/sass/app.scss)
* [responsive.scss](https://github.com/drehimself/css-grid-example/blob/master/resources/assets/sass/responsive.scss)

